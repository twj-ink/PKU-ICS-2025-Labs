/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned addval_334(unsigned x)
{
    return x + 2421708815U;
}

unsigned addval_451(unsigned x)
{
    return x + 2421715685U;
}

unsigned getval_471()
{
    return 1136890200U;
}

unsigned addval_154(unsigned x)
{
    return x + 3284633930U;
}

void setval_392(unsigned *p)
{
    *p = 3284633928U;
}

unsigned getval_283()
{
    return 1358227515U;
}

unsigned getval_162()
{
    return 2428995944U;
}

void setval_490(unsigned *p)
{
    *p = 3284633928U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

unsigned getval_376()
{
    return 3372794249U;
}

void setval_439(unsigned *p)
{
    *p = 3375945385U;
}

unsigned addval_311(unsigned x)
{
    return x + 3682912777U;
}

unsigned getval_436()
{
    return 3222847881U;
}

unsigned addval_353(unsigned x)
{
    return x + 3372269961U;
}

unsigned addval_366(unsigned x)
{
    return x + 3286272328U;
}

unsigned addval_378(unsigned x)
{
    return x + 3526940169U;
}

unsigned addval_483(unsigned x)
{
    return x + 3252717896U;
}

unsigned getval_385()
{
    return 3286288712U;
}

void setval_325(unsigned *p)
{
    *p = 3682912897U;
}

void setval_102(unsigned *p)
{
    *p = 3264272009U;
}

void setval_321(unsigned *p)
{
    *p = 2425473673U;
}

void setval_449(unsigned *p)
{
    *p = 1723979401U;
}

unsigned getval_493()
{
    return 3676362409U;
}

void setval_478(unsigned *p)
{
    *p = 2430638408U;
}

unsigned getval_180()
{
    return 3286272330U;
}

unsigned addval_109(unsigned x)
{
    return x + 2462157109U;
}

void setval_374(unsigned *p)
{
    *p = 3230974345U;
}

void setval_181(unsigned *p)
{
    *p = 3804482185U;
}

void setval_259(unsigned *p)
{
    *p = 3375417993U;
}

unsigned getval_105()
{
    return 3281046153U;
}

unsigned addval_494(unsigned x)
{
    return x + 3676357001U;
}

void setval_137(unsigned *p)
{
    *p = 3285617138U;
}

unsigned getval_243()
{
    return 3285621083U;
}

unsigned getval_335()
{
    return 2430634312U;
}

unsigned getval_115()
{
    return 3286272360U;
}

unsigned addval_158(unsigned x)
{
    return x + 3229931145U;
}

unsigned getval_457()
{
    return 3281305993U;
}

unsigned addval_400(unsigned x)
{
    return x + 3683961481U;
}

unsigned getval_202()
{
    return 2497743176U;
}

unsigned addval_293(unsigned x)
{
    return x + 415416713U;
}

void setval_479(unsigned *p)
{
    *p = 3676883593U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
